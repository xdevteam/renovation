<link rel="stylesheet" href="<?= base_url(); ?>../../../css/back_end.css" type="text/css">


<div id="fullscreen_bg" class="fullscreen_bg">

    <div class="container">
        <form class="form-signin" action="" method="post">
            <span class="form-signin-heading">Управление</span>
            <input type="text" class="form-control-auth" name="email" placeholder="Логин" required="required" autofocus="">
            <input type="password" class="form-control-auth" name="password" placeholder="Пароль" required="required">
            <button class="btn_auth" type="submit">
                Войти
            </button>
        </form>
    </div>
</div>

