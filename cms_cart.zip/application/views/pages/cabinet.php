<!-- Main Content -->

<div id="main">
    <div class="container wf-wrap">




        <div class="row">

            <!-- Cabinet Content -->
            <section id="cabinet-content" class="clearfix">

                <h2 class="cabinetHead">Главная</h2>


            </section>
            <!-- Cabinet Content End -->

        </div>

        <hr>



    </div>
</div>

<!-- Main Content End -->


