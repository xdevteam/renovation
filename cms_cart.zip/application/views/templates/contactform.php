
<div class="ctf">
    
    <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Email адрес</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputName">Имя</label>
    <input type="text" class="form-control" id="exampleInputName" placeholder="Имя">
  </div>
        <div class="form-group">
            <label for="exampleInputName">Ваше сообщение:</label>
        <textarea class="form-control" rows="3"></textarea>
   </div>
  
  <button type="submit" class="btn btn-default">Отправить</button>
</form>
    
    
    
    
</div>